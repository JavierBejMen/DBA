/* Grupo C
*  Práctica 2 de DBA
*/
package gugelcar;

/**
 * @brief Posibles movimientos del agente
 * @author Daniel Díaz Pareja, Javier Bejar Mendez
 */
public enum Movimientos {
    moveN, moveS, moveE, moveW, moveNE, moveNW, moveSE, moveSW,refuel;
}
