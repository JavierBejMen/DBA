package gugelcar;

/**
 * @brief Posibles estados del agente
 * @author Jorge 
 */
public enum Estados {
    OK, CRASHED, BAD_COMMAND, BAD_PROTOCOL, BAD_KEY;
}
